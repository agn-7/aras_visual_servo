QCIF=["QCIF_00.bmp","QCIF_01.bmp","QCIF_02.bmp","QCIF_03.bmp","QCIF_04.bmp","QCIF_05.bmp",
      "QCIF_06.bmp","QCIF_07.bmp","QCIF_08.bmp","QCIF_09.bmp","QCIF_10.bmp","QCIF_11.bmp",
      "QCIF_12.bmp","QCIF_13.bmp","QCIF_14.bmp","QCIF_15.bmp","QCIF_16.bmp","QCIF_17.bmp",
      "QCIF_18.bmp","QCIF_19.bmp","QCIF_20.bmp","QCIF_21.bmp","QCIF_22.bmp","QCIF_23.bmp",
      "QCIF_24.bmp","QCIF_25.bmp","QCIF_26.bmp","QCIF_27.bmp","QCIF_28.bmp","QCIF_29.bmp"]
